package com.demo.overcook.menu;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MenuApplicationTests {

	@Test
	void contextLoads() {
	}

}
